chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "getKeyStatus") {
    chrome.storage.local.get(["deviceId"], (result) => {
      let deviceId = result.deviceId;
      if (!deviceId) {
        deviceId = Math.random().toString(36).substring(2, 18);
        chrome.storage.local.set({
          'deviceId': deviceId
        }, () => {
          fakeKeyVerification(deviceId, sendResponse);
        });
      } else {
        fakeKeyVerification(deviceId, sendResponse);
      }
    });
    return true; // Keep async response
  }
});

function fakeKeyVerification(deviceId, sendResponse) {
  const userAgent = navigator.userAgent;
  const language = navigator.language;
  const platform = navigator.platform;
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  
  const keyData = `${deviceId}|${userAgent}|${language}|${platform}|${timeZone}`;
  const encodedKey = btoa(keyData);

  // Immediately approve access without remote check
  sendResponse({
    access: true,  // Always approved
    key: encodedKey
  });
}